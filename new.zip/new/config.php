<?php 
$con=new mysqli("localhost","root","","place")or die(mysqli_error());

 ?>
