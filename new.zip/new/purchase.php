<?php include("side.php");
?>
<div class="page-wrapper">
<div class="content container-fluid">

<div class="page-header">
<div class="row align-items-center">
<div class="col">
<h3 class="page-title">Report Of All Purchase</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item"><a href="purchase.php">Purchase</a></li>
<li class="breadcrumb-item"><a href="add-sale.php">Sales</a></li>

<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
<li class="breadcrumb-item active">Products</li>
</ul>
</div>
<div class="col-auto text-right float-right ml-auto">
<a href="#" class="btn btn-outline-primary mr-2"><i class="fas fa-download"></i> Download</a>
<a href="add-roll.php" class="btn btn-primary"><i class="fas fa-plus"></i></a>
</div>
</div>
</div>
<div class="row">
<div class="col-sm-12">
<div class="card card-table">
<div class="card-body">
<div class="table-responsive">
<table class="table table-hover table-center mb-0 datatable">
<thead>
<tr>
<th>#</th>
<th>Customer Code</th>
<th>Product Name</th>
<th>Quantity</th>
<th>Price</th>
<th>Total Price</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>

<?php 
include("config.php");
$sel=$con->query("SELECT * FROM purchase  WHERE cust_code='$_SESSION[cust_code]'")or die(mysqli_error());
$n=1;
while($row=mysqli_fetch_array($sel)){

?>
<tbody>
<tr>
<td><?php echo $n; ?></td>
	<td><?php echo $row["cust_code"]; ?></td>
	<td><?php echo $row["product_name"]; ?></td>
	<td><?php echo $row["quantity"]; ?></td>
	<td><?php echo $row["price"]; ?></td>	
	<td><?php echo $row["total"]; ?></td>
	<td><?php echo $row["date"]; ?></td>	
<td>
<div class="actions">
<span onclick="document.getElementById('id01').style.display='block'" class="btn btn-sm bg-success-light mr-2">

<i class="fas fa-shopping-cart">Purchase</i>
</a> </span>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="add-sale.php" class="btn btn-sm bg-danger-light">
<i class="fas fa-minus">Stock Out</i>
</a>
</div>
</td>
</tr>
<?php $n++;} ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>





<script src="assets/js/jquery-3.6.0.min.js"></script>

<script src="assets/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<script src="assets/plugins/datatables/datatables.min.js"></script>

<script src="assets/js/script.js"></script>