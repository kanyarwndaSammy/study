 <?php
 include("side.php");
include("config.php");
if(isset($_POST['save'])){

	$a=$_POST['name'];
	$b=$_POST['ref'];
	$c=$_POST['quantity'];
	$d=$_POST['price'];
	$tt=$d*$c;
	// if ($c=="") {
	// echo "<script>alert('sorry try again')</script>";
	// }
	// else{
	$se=$con->query("SELECT * FROM products WHERE product_name ='$a'")or die(mysqli_error());
	$q=mysqli_fetch_array($se);
	if($q["product_name"]==$a){
		$t=$q["quantity"]+$c;
		$u=$con->query("UPDATE products SET quantity='$t' WHERE product_name='$a'")or die(mysqli_error());
	$in=$con->query("INSERT INTO purchase VALUES('','$b','$a','$c','$d','$tt',now())")or die(mysqli_error());
		
		echo"<script>alert('new item was recorded');window.location.replace('products.php')</script>";
	}
	else{
	$in=$con->query("INSERT INTO products VALUES('','$b','$a','$c')")or die(mysqli_error());

		echo"<script>alert('new item was not recorded');window.location.replace('products.php')</script>";

	}}
// }
 ?>

<!-- login page -->
