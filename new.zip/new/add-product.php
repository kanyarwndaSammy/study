<?php include("side.php"); ?>
<div class="page-wrapper">
<div class="content container-fluid">

<div class="page-header">
<div class="row align-items-center">
<div class="col">
<h3 class="page-title">Add Purchase</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item"><a href="products.php">Products</a></li>
<li class="breadcrumb-item active">Add Purchase</li>
</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-sm-12">
<div class="card">
<div class="card-body">
<form method="post">
<div class="row">
<div class="col-12">
<h5 class="form-title"><span>Purchase Information</span></h5>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">

<label >Product  Name</label>
<select name="name" class="form-control">
	<option>Select Product Name</option>
	<?php 
include("config.php");
	$sel=$con->query("SELECT * FROM products")or die(mysqli_error());
while ($r=mysqli_fetch_array($sel)) {
	$sa=$r["product_name"];
	echo "<option value='$r[pro_id]'>".$sa."</option>";
}
	 ?>
</select>
</div>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">
<label>Ref Name</label>
<select class="form-control" name="ref">
	<option>Select Ref Name</option>

	<?php 
include("config.php");
	$sel=$con->query("SELECT * FROM products WHERE product_name='$sa'")or die(mysqli_error());
while ($r=mysqli_fetch_array($sel)) {
	echo "<option>".$r["ref"]."</option>";
}
	 ?>
</select>
</div>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">
<label>Quantity</label>
<input type="text" name="quantity" class="form-control" placeholder="Enter Products Quantity">
</div>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">
<label>Price</label>
<input type="date" name="price" class="form-control" placeholder="Enter Products Price">
</div>
</div>

<div class="col-12">
	<div class="form-group">
<button type="submit" name="save" class="btn btn-primary">Save Purchase Records</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
<?php

if(isset($_POST['save'])){

	$a=$_POST['name'];
	$b=$_POST['ref'];
	$c=$_POST['quantity'];
	$d=$_POST['price'];
	$tt=$d*$c;
	$in=$con->query("INSERT INTO purchase VALUES('','$a','$b','$c','$d','$tt',now())")or die(mysqli_error());
	$se=$con->query("SELECT * FROM products WHERE pro_id ='$a'")or die(mysqli_error());
	$q=mysqli_fetch_array($se);
	if($q["pro_id"]==$a){
		$t=$q["quantity"]+$c;
		$u=$con->query("UPDATE products SET quantity='$t' WHERE pro_id='$a'")or die(mysqli_error());
		echo"<script>alert('new item was recorded');window.location.replace('add-product.php')</script>";
	}
	else{
	$in=$con->query("INSERT INTO products VALUES('','$a','$b','')")or die(mysqli_error());
		echo"<script>alert('new item was not recorded');window.location.replace('add-product.php')</script>";

	}
}
 ?>

<script src="assets/js/jquery-3.6.0.min.js"></script>

<script src="assets/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<script src="assets/js/script.js"></script>
</body>

</html>