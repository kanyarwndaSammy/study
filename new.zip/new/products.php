<?php
include("side.php");
include("config.php");
 ?>

<div class="page-wrapper">
<div class="content container-fluid">

<div class="page-header">
<div class="row align-items-center">
<div class="col">
<h3 class="page-title">Products</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item"><a href="purchase.php">Purchase</a></li>
<li class="breadcrumb-item"><a href="add-sale.php">Sales</a></li>

<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
<li class="breadcrumb-item active">Products</li>
</ul>
</div>
<div class="col-auto text-right float-right ml-auto">
<a href="add-products.php" class="btn btn-outline-primary mr-2" class="btn btn-primary"><i class="fas fa-plus">Add Products</i></a>
</div>

</div>
</div>

<div class="row">
<div class="col-sm-12">
<div class="card card-table">
<div class="card-body">
<div class="table-responsive">
<table class="table table-hover table-center mb-0 datatable">
<thead>
<tr>
<th>#</th>
<th>Customer Code</th>
<th>Product Name</th>
<th>Quality</th>
<th>Action</th>
</tr>
</thead>

<?php 
$sel=$con->query("SELECT * from products  ")or die(mysqli_error());
$n=1;
while($row=mysqli_fetch_array($sel)){

?>
<tbody>
<tr>
<td><?php echo $n; ?></td>
	<td><?php echo $row['cust_id']; ?></td>

	<td><?php echo $row['product_name']; ?></td>
	<td><?php echo $row['quantity']; ?></td>	
<td>
<div class="actions">
<span onclick="document.getElementById('id01').style.display='block'" class="btn btn-sm bg-success-light mr-2">

<i class="fas fa-shopping-cart">Purchase</i>
</a> </span>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="add-sale.php" class="btn btn-sm bg-danger-light">
<i class="fas fa-minus">Stock Out</i>
</a>
</div>
</td>
</tr>
<?php $n++;} ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>


</div>

</div>


<script src="assets/js/jquery-3.6.0.min.js"></script>

<script src="assets/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<script src="assets/plugins/datatables/datatables.min.js"></script>

<script src="assets/js/script.js"></script>
</body>

</html>
</body>
</html>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 50%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
<div id="id01" class="modal">
  
  <form class="modal-content animate"   method="post">
  	<div class="container">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <h2>Fill Purchase Form</h2>
    
<div class="row">
<div class="col-12">
<h5 class="form-title"><span>Purchase Information</span></h5>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">

<label >Product  Name</label>
<select name="name" class="form-control" required>
	<option>Select Product Name</option>
	<?php 
include("config.php");
	$sel=$con->query("SELECT * FROM products")or die(mysqli_error());
while ($r=mysqli_fetch_array($sel)) {
  $as=$r["cust_id"];
	echo "<option value='$r[productid]'>".$r["product_name"]."</option>";
}
	 ?>
</select>
</div>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">
<label>Customer Name</label>
<select class="form-control" name="ref" >
  <option>Choose Customer Code</option>
  <?php 
include("config.php");
  $sel=$con->query("SELECT * FROM customer WHERE cust_id='$as'")or die(mysqli_error());
while ($r=mysqli_fetch_array($sel)) {
  echo "<option>".$r["cust_code"]."</option>";
}
   ?>
</select>
</div>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">
<label>Quantity</label>
<input type="text" name="quantity" class="form-control" placeholder="Enter Products Quantity" required="required">
</div>
</div>
<div class="col-12 col-sm-6">
<div class="form-group">
<label>Price</label>
<input type="text" name="price" class="form-control" placeholder="Enter Products Price" required="required">
</div>
</div>

<div class="col-12">
	<div class="form-group">
<button type="submit" name="save" class="btn btn-primary">Save Purchase Records</button>
</div>
</div>
</div>
</div>
  </form>

</div>
 <?php
if(isset($_POST['save'])){

  $a=$_POST['name'];
  $b=$_POST['ref'];
  $c=$_POST['quantity'];
  $d=$_POST['price'];
  $tt=$d*$c;
  // if ($c=="") {
  // echo "<script>alert('sorry try again')</script>";
  // }
  // else{
  $in=$con->query("INSERT INTO purchase VALUES('','$b','$a','$c','$d','$tt',now())")or die(mysqli_error());

  $se=$con->query("SELECT * FROM products WHERE product_name ='$a'")or die(mysqli_error());
  $q=mysqli_fetch_array($se);
  if($q["product_name"]==$a){
    $t=$q["quantity"]+$c;
    $u=$con->query("UPDATE products SET quantity='$t' WHERE product_name='$a'")or die(mysqli_error());
    
    echo"<script>alert('new item was recorded');window.location.replace('products.php')</script>";
  }
  else{
  $in=$con->query("INSERT INTO products VALUES('','$b','$a','$c')")or die(mysqli_error());

    echo"<script>alert('new item was not recorded');window.location.replace('products.php')</script>";

  }}
// }
 ?>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>